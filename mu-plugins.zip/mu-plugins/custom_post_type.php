<?php 



function my_custom_post_type(){

	// Laravel Post Type
	  register_post_type('laravel', array(
	    'supports' => array('title', 'editor', 'thumbnail'),
	    'public' => true,
	    'labels' => array(
	      'name' => 'LaravelCode',
	      'add_new_item' => 'Add New Laravel-Code',
	      'edit_item' => 'Edit Laravel-Code',
	      'all_items' => 'All Laravel-Code',
	      'singular_name' => 'Laravel-Code'
	    ),
	    'menu_icon' => 'dashicons-welcome-learn-more'
	  ));


	// Wordpress Post Type
	  register_post_type('mwordpress', array(
	  	'rewrite' => array( 'slug' => 'wordpress'),
	  	'has_archive' => true,
	  	'menu_position' => 11,
	  	'slug' => 'mwordpress',
	    'supports' => array('title', 'editor', 'thumbnail','excerpt'),
	    'public' => true,
	    'labels' => array(
	      'name' => 'Wordpress Code',
	      'add_new_item' => 'Add New Wordpress-Code',
	      'edit_item' => 'Edit Wordpress-Code',
	      'all_items' => 'All Wordpress-Code',
	      'singular_name' => 'Wordpress-Code'
	    ),
	    'menu_icon' => 'dashicons-wordpress'
	  ));

	// Android Post Type
	  register_post_type('android', array(
	  	'menu_position' => 11,
	    'supports' => array('title', 'editor', 'thumbnail'),
	    'public' => true,
	    'labels' => array(
	      'name' => 'Android Code',
	      'add_new_item' => 'Add New Android-Code',
	      'edit_item' => 'Edit Android-Code',
	      'all_items' => 'All Android-Code',
	      'singular_name' => 'Android-Code'
	    ),
	    'menu_icon' => 'dashicons-video-alt3'
	  ));


}
add_action('init', 'my_custom_post_type');

 ?>
