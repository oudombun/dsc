<?php get_header(); ?>



<!-- Mobile menu -->
<div class="mob-menu-wrapper hidden-md hidden-lg">
    <div class="close-mob-menu">
        <span><i class="mdi mdi-close" aria-hidden="true"></i></span>
    </div>
    <div class="mobile-menu">
        <ul>
            <li><a href="#hello">Home</a></li>
            <li><a href="#hello">Laravel</a></li>
            <li><a href="#hello">Wordpress</a></li>
            <li><a href="#hello">Android</a></li>
        </ul>
    </div>
</div>
<!-- Mobile menu -->

<section id="hello" class="section">
    <div class="container">
        <div class="row">
            <div class="col-md-6 about-img-wrap">
                <div class="about-img wow slideInRight">
                    <img src="<?php echo get_theme_file_uri('/media/hello-section/me.jpg'); ?>" alt="" class="img-responsive">
                </div>
            </div>
            <div class="col-md-6">
                <div class="about-me wow slideInLeft">
                    <div class="about-me-title">
                        <h1><span class="point">I am Monyoudom Bun</span></h1>
                    </div>
                    <div class="about-me-text">
                        <div class="opacity-box">
                            <p>I am a Web Developer located in Phnompenh. I currently work
                                as a full time Web Developer for Plan-B Cambodia, located in Cambodia. I am looking to take on more work and to increase my skills as
                                a Web Developer.</p>
                        </div>
                    </div>
                    <div class="about-me-info">
                        <p>
                            <span class="span-title">Phone</span>
                            <span>+855 93775782</span>
                        </p>
                        <p>
                            <span class="span-title">Email</span>
                            <span>oudombun262@gmail.com</span>
                        </p>
                        <p>
                            <span class="span-title">Address</span>
                            <span>330 street ,BKK3 , Chamkamon Phnom Penh</span>
                        </p>
                        <p>
                            <span class="span-title">Social</span>
                            <span class="span-icons">
                                <a target="_blank" href="https://www.facebook.com/ah.dom.75" class="mdi fonts-icons mdi-facebook"></a>
                                <a target="_blank" href="https://github.com/oudombun" class="mdi fonts-icons mdi-github-circle"></a>
                               <!--  <a target="_blank" href="https://twitter.com/" class="mdi fonts-icons mdi-twitter"></a>
                                <a target="_blank" href="https://www.instagram.com/" class="mdi fonts-icons mdi-instagram"></a> -->
                            </span>
                        </p>
                    </div>
                    <div class="about-btns">
                        <a data-toggle="modal" data-target="#contact-modal" href="#" class="site-btn">Contact me</a>
                        <a href="#" class="site-btn gray-btn">Download cv</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section id="skills" class="section">
    <div class="container">
        <div class="row wave-bg">
            <div class="zigzag wow slideInLeft">
                <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" x="0px" y="0px" viewBox="0 0 105 20" xml:space="preserve">
                    <g>
                        <rect class="st0" width="105" height="20"/>
                        <g>
                            <polyline class="st1" points="2.5,5 16.8,15 31.1,5 45.3,15 59.6,5 73.9,15 88.2,5 102.5,15   "/>
                        </g>
                    </g>
                </svg>
                <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" x="0px" y="0px" viewBox="0 0 105 20" xml:space="preserve">
                    <g>
                        <rect class="st0" width="105" height="20"/>
                        <g>
                            <polyline class="st1" points="2.5,5 16.8,15 31.1,5 45.3,15 59.6,5 73.9,15 88.2,5 102.5,15   "/>
                        </g>
                    </g>
                </svg>
            </div>
            <div class="col-md-4 wow slideInLeft">
                <div class="section-sidebar">
                    <h2><span class="point">Skills</span></h2>
                    <div class="opacity-box">
                        <p>I am inspired by creating great work with people who are as passionate as I am about building something awesome.</p>
                    </div>
                </div>
            </div>
            <div class="col-md-8">
                <div class="row">
                    <div class="col-md-6 wow zoomIn">
                        <div class="advantages-box">
                            <h4>Web Development</h4>
                            <div class="opacity-box">
                                <p>Javascript, Jquery, JAVA, C#, PHP, Node.js, MongoDB, PostgreSQL. </p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 wow zoomIn">
                        <hr class="mobile-hr">
                        <div class="advantages-box">
                            <h4>UI\UX Design</h4>
                            <div class="opacity-box">
                                <p>Photoshop, Illustrator, Sketch, Axure, XMind, Prototyping, Wireframing, User Research, Usability Testing.</p>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-6 wow zoomIn">
                        <hr>
                        <div class="advantages-box">
                            <h4>Frontend Development</h4>
                            <div class="opacity-box">
                                <p>HTML, CSS, LESS, SASS, Bootstrap, Wordpress, Drupal, Phonegap / Cordova, Ionic, Foundation, Angular.js.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 wow zoomIn">
                        <hr>
                        <div class="advantages-box">
                            <h4>Consulting & SEO Audit</h4>
                            <div class="opacity-box">
                                <p>Screaming Frog, Woorank, Raventools, Semrush, Moz, WebCEO, Google Analytics, ChartBeat, CrazyEgg.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section id="experience" class="section">
    <div class="container">
        <div class="row wave-bg">
            <div class="zigzag wow slideInLeft">
                <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" x="0px" y="0px" viewBox="0 0 105 20" xml:space="preserve">
                    <g>
                       <rect class="st0" width="105" height="20"/>
                        <g>
                            <polyline class="st1" points="2.5,5 16.8,15 31.1,5 45.3,15 59.6,5 73.9,15 88.2,5 102.5,15   "/>
                        </g>
                    </g>
                </svg>
                <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" x="0px" y="0px" viewBox="0 0 105 20" xml:space="preserve">
                    <g>
                        <rect class="st0" width="105" height="20"/>
                        <g>
                            <polyline class="st1" points="2.5,5 16.8,15 31.1,5 45.3,15 59.6,5 73.9,15 88.2,5 102.5,15   "/>
                        </g>
                    </g>
                </svg>
            </div>
            <div class="col-md-4 wow slideInLeft">
                <div class="section-sidebar">
                    <h2><span class="point">Experience</span></h2>
                    <div class="opacity-box">
                        <p>I partner with startups, organizations and Fortune 500 companies to build digital products
                            that help clients overcome challenges and create lasting connections with
                            millions of people every day.</p>
                    </div>
                </div>
            </div>
            <div class="col-md-8 right-box">
                <div class="row wow zoomIn">
                    <div class="col-md-12">
                        <div class="about-row">
                            <h4 class="about-tittle">Web Developer</h4>
                            <p class="about-info">Coolor Studio</p>
                            <p>May, 2014 — Present</p>
                            <div class="opacity-box">
                                <p>Designed and developed user-friendly website, including optimized check-out
                                    page that increased user clicks, and subsequently customer purchases by 20%.</p>
                            </div>
                        </div>
                    </div>
                </div>
                <hr>
                <div class="row wow zoomIn">
                    <div class="col-md-12">
                        <div class="about-row">
                            <h4 class="about-tittle">Middle Frontend Developer</h4>
                            <p class="about-info">Illskill Agency</p>
                            <p>Jan, 2013 — May, 2014</p>
                            <div class="opacity-box">
                                <p>Leading a small team on a variety of development projects and delivering
                                    solutions to meet and exceed clients’ briefs.</p>
                            </div>
                        </div>
                    </div>
                </div>
                <hr>
                <div class="row wow zoomIn">
                    <div class="col-md-12">
                        <div class="about-row">
                            <h4 class="about-tittle">IT Specialist</h4>
                            <p class="about-info">Motion Studio</p>
                            <p>Dec, 2009 — Jan, 2013</p>
                            <div class="opacity-box">
                                <p>Revamped web application security applications, minimizing hacker
                                    attacks from 2.3% to 0.02%.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section id="education" class="section">
    <div class="container">
        <div class="row wave-bg">
            <div class="zigzag wow slideInLeft">
                <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" x="0px" y="0px" viewBox="0 0 105 20" xml:space="preserve">
                    <g>
                        <rect class="st0" width="105" height="20"/>
                        <g>
                            <polyline class="st1" points="2.5,5 16.8,15 31.1,5 45.3,15 59.6,5 73.9,15 88.2,5 102.5,15   "/>
                        </g>
                    </g>
                </svg>
                <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" x="0px" y="0px" viewBox="0 0 105 20" xml:space="preserve">
                    <g>
                        <rect class="st0" width="105" height="20"/>
                        <g>
                            <polyline class="st1" points="2.5,5 16.8,15 31.1,5 45.3,15 59.6,5 73.9,15 88.2,5 102.5,15   "/>
                        </g>
                    </g>
                </svg>
            </div>
            <div class="col-md-4 wow slideInLeft">
                <div class="section-sidebar">
                    <h2><span class="point">Education</span></h2>
                    <div class="opacity-box">
                        <p>All my life I have been driven by my strong belief that education
                            is important. I try to learn something new every single day.</p>
                    </div>
                </div>
            </div>
            <div class="col-md-8 right-box">
                <div class="row wow zoomIn">
                    <div class="col-md-12">
                        <div class="about-row">
                            <h4 class="about-tittle">Google Developer Training</h4>
                            <p class="about-info">Google</p>
                            <p>Apr, 2015 — May, 2015</p>
                            <div class="opacity-box">
                                <p>Learn to use App Engine, Google's Platform as a Service, to build the backend for
                                    web apps that scale not only as your user base grows but as request volumes
                                    peaks with sudden demand.</p>
                            </div>
                        </div>
                    </div>
                </div>
                <hr>
                <div class="row wow zoomIn">
                    <div class="col-md-12">
                        <div class="about-row">
                            <h4 class="about-tittle">Software Development</h4>
                            <p class="about-info">Boston University</p>
                            <p>Jan, 2005 — May, 2009</p>
                            <div class="opacity-box">
                                <p>BSc (Hons) in Software Development. Outstanding Academic Achievement Award.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section id="portfolio" class="section section-small-padding">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="section-title wow slideInLeft">
                    <h2><span class="point">Portfolio</span></h2>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="portfolio-sort wow slideInLeft">
                    <ul class="list-inline">
                        <li class="colored-link" data-mixitup-control data-filter="all">All projects</li>
                        <li class="colored-link" data-mixitup-control data-filter=".web-sites">Laravel</li>
                        <li class="colored-link" data-mixitup-control data-filter=".ui-ux-design">Wordpress</li>
                        <li class="colored-link" data-mixitup-control data-filter=".frontend">Android</li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="portfolio">
                    <div class="row">
                        <div class="col-md-3 col-sm-6 col-xs-6 mix web-sites wow flipInX">
                            <a data-toggle="modal" data-target="#portfolio-modal" data-name="patty" title="Shop web app “Patty”" href="#" class="portfolio-box">
                                <div class="portfolio-img">
                                    <img src="<?php echo get_theme_file_uri('/media/portfolio-images/portfolio-1.jpg'); ?> " alt="">
                                </div>
                                <div class="portfolio-name">
                                    <span>Shop web app “Patty”</span>
                                </div>
                                <div class="portfolio-date">
                                    <span>April, 2017</span>
                                </div>
                            </a>
                        </div>
                        <div class="col-md-3 col-sm-6 col-xs-6 mix frontend wow flipInX">
                            <a data-toggle="modal" data-target="#portfolio-modal" data-name="phoenix" title="Startup website “Phoenix”" href="#" class="portfolio-box">
                                <div class="portfolio-img">
                                    <img src="<?php echo get_theme_file_uri('/media/portfolio-images/portfolio-2.jpg'); ?> " alt="">
                                </div>
                                <div class="portfolio-name">
                                    <span>Startup website “Phoenix”</span>
                                </div>
                                <div class="portfolio-date">
                                    <span>March, 2016</span>
                                </div>
                            </a>
                        </div>
                        <div class="col-md-3 col-sm-6 col-xs-6 mix web-sites wow flipInX">
                            <a data-toggle="modal" data-target="#portfolio-modal" data-name="ewesta" title="Corporate chat “eWesta”" href="#" class="portfolio-box">
                                <div class="portfolio-img">
                                    <img src="<?php echo get_theme_file_uri('/media/portfolio-images/portfolio-3.jpg'); ?> " alt="">
                                </div>
                                <div class="portfolio-name">
                                    <span>Corporate chat “eWesta”</span>
                                </div>
                                <div class="portfolio-date">
                                    <span>December, 2015</span>
                                </div>
                            </a>
                        </div>
                        <div class="col-md-3 col-sm-6 col-xs-6 mix frontend wow flipInX">
                            <a data-toggle="modal" data-target="#portfolio-modal" data-name="foody"  title="Restaraunt web app “Foody”" href="#" class="portfolio-box">
                                <div class="portfolio-img">
                                    <img src="<?php echo get_theme_file_uri('/media/portfolio-images/portfolio-4.jpg'); ?> " alt="">
                                </div>
                                <div class="portfolio-name">
                                    <span>Restaraunt web app “Foody”</span>
                                </div>
                                <div class="portfolio-date">
                                    <span>May, 2014</span>
                                </div>
                            </a>
                        </div>
                        <div class="col-md-3 col-sm-6 col-xs-6 mix ui-ux-design wow flipInX">
                            <a data-toggle="modal" data-target="#portfolio-modal" data-name="stark" title="Game website “Stark”" href="#" class="portfolio-box">
                                <div class="portfolio-img">
                                    <img src="<?php echo get_theme_file_uri('/media/portfolio-images/portfolio-5.jpg'); ?> " alt="">
                                </div>
                                <div class="portfolio-name">
                                    <span>Game website “Stark”</span>
                                </div>
                                <div class="portfolio-date">
                                    <span>June, 2014</span>
                                </div>
                            </a>
                        </div>
                        <div class="col-md-3 col-sm-6 col-xs-6 mix web-sites wow flipInX">
                            <a data-toggle="modal" data-target="#portfolio-modal" data-name="te4h" title="Blogger website “Te4h”" href="#" class="portfolio-box">
                                <div class="portfolio-img">
                                    <img src="<?php echo get_theme_file_uri('/media/portfolio-images/portfolio-6.jpg'); ?>" alt="">
                                </div>
                                <div class="portfolio-name">
                                    <span>Blogger website “Te4h”</span>
                                </div>
                                <div class="portfolio-date">
                                    <span>April, 2014</span>
                                </div>
                            </a>
                        </div>
                        <div class="col-md-3 col-sm-6 col-xs-6 mix frontend wow flipInX">
                            <a data-toggle="modal" data-target="#portfolio-modal" data-name="lamp" title="Product website “Lamp”" href="#" class="portfolio-box">
                                <div class="portfolio-img">
                                    <img src="<?php echo get_theme_file_uri('/media/portfolio-images/portfolio-7.jpg'); ?>" alt="">
                                </div>
                                <div class="portfolio-name">
                                    <span>Product website “Lamp”</span>
                                </div>
                                <div class="portfolio-date">
                                    <span>December, 2013</span>
                                </div>
                            </a>
                        </div>
                        <div class="col-md-3 col-sm-6 col-xs-6 mix ui-ux-design wow flipInX">
                            <a data-toggle="modal" data-target="#portfolio-modal" data-name="zebra" title="Blog web app “Zebra”" href="#" class="portfolio-box">
                                <div class="portfolio-img">
                                    <img src="<?php echo get_theme_file_uri('/media/portfolio-images/portfolio-8.jpg'); ?> " alt="">
                                </div>
                                <div class="portfolio-name">
                                    <span>Blog web app “Zebra”</span>
                                </div>
                                <div class="portfolio-date">
                                    <span>March, 2013</span>
                                </div>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section id="feedback" class="section">
    <div class="container">
        <div class="row wave-bg">
            <div class="zigzag wow slideInLeft">
                <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" x="0px" y="0px" viewBox="0 0 105 20" xml:space="preserve">
                    <g>
                        <rect class="st0" width="105" height="20"/>
                        <g>
                            <polyline class="st1" points="2.5,5 16.8,15 31.1,5 45.3,15 59.6,5 73.9,15 88.2,5 102.5,15   "/>
                        </g>
                    </g>
                </svg>
                <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" x="0px" y="0px" viewBox="0 0 105 20" xml:space="preserve">
                    <g>
                        <rect class="st0" width="105" height="20"/>
                        <g>
                            <polyline class="st1" points="2.5,5 16.8,15 31.1,5 45.3,15 59.6,5 73.9,15 88.2,5 102.5,15   "/>
                        </g>
                    </g>
                </svg>
            </div>
            <div class="col-md-4 wow slideInLeft">
                <div class="section-sidebar">
                    <h2><span class="point">Feedback</span></h2>
                    <div class="opacity-box">
                        <p>Take a look at the reviews of my customers and ensure the quality of my services.</p>
                    </div>
                </div>
            </div>
            <div class="col-md-8 right-box">
                <div class="row wow zoomIn">
                    <div class="col-md-12">
                        <div class="feedback-block">
                            <img class="feedback-image" src="<?php echo get_theme_file_uri('/media/feedback-images/feedback-1.jpg'); ?> " alt="">
                            <h4 class="about-tittle">Stacey Don</h4>
                            <p class="about-info">President @ Coolor Studio</p>
                            <div class="opacity-box">
                                <p>"Considers problems as a challenge and enjoys finding creative yet appropriate
                                    solutions. Danny is able to work out his own solutions, but also works
                                    well with a group to solve problems. Performs most jobs well and has the
                                    habit of checking work outcomes. Danny is achieving excellence in some areas
                                    but in others is not yet achieving the highest standards.""</p>
                            </div>
                        </div>
                    </div>
                </div>
                <hr>
                <div class="row wow zoomIn">
                    <div class="col-md-12">
                        <div class="feedback-block">
                            <img class="feedback-image" src="<?php echo get_theme_file_uri('/media/feedback-images/feedback-2.jpg'); ?> " alt="">
                            <h4 class="about-tittle">Anson Shura</h4>
                            <p class="about-info">Project Manager @ Motion Studio</p>
                            <div class="opacity-box">
                                <p>“He will always try to do what is required, even if it means performing tasks that
                                  are not in the job description or if required to do extra work unexpectedly. However,
                                  may sometimes complain about the extra load. Aiming for a top job in the organization.
                                  He sets very high standards, aware that this will bring attention and promotion.”</p>
                            </div>
                        </div>
                    </div>
                </div>
                <hr>
                <div class="row wow zoomIn">
                    <div class="col-md-12">
                        <div class="feedback-block">
                            <img class="feedback-image" src="<?php echo get_theme_file_uri('/media/feedback-images/feedback-3.jpg'); ?> " alt="">
                            <h4 class="about-tittle">Gaylord Jefferson</h4>
                            <p class="about-info">Developer @ Illskill Agency</p>
                            <div class="opacity-box">
                                <p>“When working to a firm but realistic deadline, Danny always completes tasks to a
                                   high standard. Care and accuracy is obvious even when put under pressure of time.
                                   Prepared to work all the extra hours it takes to meet the deadline.”</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section id="contact" class="section">
    <div class="container">
        <div class="row wave-bg">
            <div class="zigzag wow slideInLeft">
                <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" x="0px" y="0px" viewBox="0 0 105 20" xml:space="preserve">
                    <g>
                        <rect class="st0" width="105" height="20"/>
                        <g>
                            <polyline class="st1" points="2.5,5 16.8,15 31.1,5 45.3,15 59.6,5 73.9,15 88.2,5 102.5,15   "/>
                        </g>
                    </g>
                </svg>
                <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" x="0px" y="0px" viewBox="0 0 105 20" xml:space="preserve">
                    <g>
                        <rect class="st0" width="105" height="20"/>
                        <g>
                            <polyline class="st1" points="2.5,5 16.8,15 31.1,5 45.3,15 59.6,5 73.9,15 88.2,5 102.5,15   "/>
                        </g>
                    </g>
                </svg>
            </div>
            <div class="col-md-4 wow slideInLeft">
                <div class="section-sidebar">
                    <h2><span class="point">Contact</span></h2>
                    <div class="opacity-box">
                        <p>Are you working on something great? I would love to help make it
                            happen! Drop me a letter and start your project right now! Just do it.</p>
                    </div>
                </div>
            </div>
            <form action="#" class="wow slideInRight js-footer-form">
                <div class="form-wrapper">
                    <div class="col-md-3">
                        <div class="form-group">
                            <input class="form-field js-field-name" type="text" placeholder="Name" required>
                            <span class="form-validation"></span>
                            <span class="form-invalid-icon"><i class="mdi mdi-close" aria-hidden="true"></i></span>
                        </div>

                        <div class="form-group">
                            <input class="form-field js-field-email" type="email" placeholder="E-mail" required>
                            <span class="form-validation"></span>
                            <span class="form-invalid-icon"><i class="mdi mdi-close" aria-hidden="true"></i></span>
                        </div>
                    </div>
                    <div class="col-md-5">
                        <div class="form-group">
                            <textarea class="form-field js-field-message" placeholder="Message" required></textarea>
                            <span class="form-validation"></span>
                        </div>
                        <div class="submit-holder">
                            <input class="site-btn" type="submit" value="Send message">
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</section>



<?php get_footer(); ?>
