function myFunction(id) {
	$('#wordpress-modal'+id).modal('hide');
	$('.tests').addClass('jaja');
  /* Get the text field */
  var copyText = document.getElementById("myInput"+id);

  /* Select the text field */
  copyText.select();

  /* Copy the text inside the text field */
  document.execCommand("copy");
	
	$('.tests').removeClass('jaja');
 
	// Get the snackbar DIV
    var x = document.getElementById("snackbar");

    // Add the "show" class to DIV
    x.className = "show";

    // After 3 seconds, remove the show class from DIV
    setTimeout(function(){ x.className = x.className.replace("show", ""); }, 3000);

}
function myFunction2(id) {
  $('#wordpress-modal'+id).modal('hide');
  $('.tests').addClass('jaja');
  /* Get the text field */
  var copyText = document.getElementById("front"+id);
// $("br").remove();
  /* Select the text field */
  copyText.select();

  /* Copy the text inside the text field */
  document.execCommand("copy");
  
  $('.tests').removeClass('jaja');
 
  // Get the snackbar DIV
    var x = document.getElementById("snackbar");

    // Add the "show" class to DIV
    x.className = "show";

    // After 3 seconds, remove the show class from DIV
    setTimeout(function(){ x.className = x.className.replace("show", ""); }, 3000);

}