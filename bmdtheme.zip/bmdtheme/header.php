<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php wp_head(); ?>
</head>
<body>
    <header class="header" style="position: unset;">
        <div class="container">
            <div class="row">
                <div class="col-md-3 col-xs-8 slideInLeft">
                    <div class="logo">
                        <span class="point">Oudom</span>
                    </div>
                </div>
                <div class="col-md-9 hidden-sm hidden-xs slideInRight">
                    <div class="main-menu">
                        <ul class="list-inline">
                            <li <?php if (is_home()) {
                                echo 'class="active"';
                            } ?> ><a href="<?php echo site_url('/'); ?>">Home</a></li>
                            <li><a href="<?php echo get_post_type_archive_link('mwordpress'); ?>">Wordpress</a></li>
                            <li><a href="#">Android</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-xs-4 hidden-lg hidden-md slideInRight">
                    <div class="mobile-btn">
                        <span><i class="mdi mdi-menu" aria-hidden="true"></i></span>
                    </div>
                </div>
            </div>
        </div>

    </header>
    <script type="text/javascript">
        
    </script>   