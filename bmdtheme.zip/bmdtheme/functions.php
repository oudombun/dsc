<?php 
	/*1 add style*/
	function add_style(){
		wp_enqueue_style('style1',get_stylesheet_uri());
		wp_enqueue_style('style2',get_theme_file_uri('/css/master.css'));
		wp_enqueue_style('style3','//fonts.googleapis.com/css?family=Lato|Roboto');
		wp_enqueue_style('style4','//cdn.materialdesignicons.com/2.0.46/css/materialdesignicons.min.css');

	}
	add_action('wp_enqueue_scripts','add_style');

	/*2 add script*/
	function add_script(){
		wp_deregister_script('jquery');
		wp_enqueue_script('jquery', 'https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js', array(), null, 	true);
		wp_register_script( 'bs-js', 'https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js', null, null, true );
		wp_enqueue_script('bs-js');
		wp_enqueue_script('script3',get_template_directory_uri()."/js/jquery.placeholder.min.js",null,'1.0',true);
		wp_enqueue_script('script4',get_template_directory_uri()."/assets/mixitup-v3/dist/mixitup.min.js",null,'1.0',true);
		wp_enqueue_script('script4',get_template_directory_uri()."/js/wow.min.js",null,'1.0',true);
		wp_enqueue_script('script5',get_template_directory_uri()."/js/theme.js",null,'1.0',true);
		wp_enqueue_script('script6',get_theme_file_uri('/js/custom.js'),null,'3.3.1',true);
	}
	add_action('wp_enqueue_scripts','add_script');

	/*add theme support */
	function bmd_feature() {
	  add_theme_support('title-tag');
	  add_theme_support('post-thumbnails');
	  add_image_size('mypost_image',270,270,true);
	}

	add_action('after_setup_theme', 'bmd_feature');

	/*tse*/
	


 ?>