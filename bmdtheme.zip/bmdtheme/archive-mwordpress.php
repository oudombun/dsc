<?php get_header(); ?>


<section id="portfolio" class="section section-small-padding">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="section-title wow slideInLeft">
                    <h2><span class="point">Important Code</span></h2>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="portfolio-sort wow slideInLeft">
                    <ul class="list-inline">
                        <li class="colored-link" data-mixitup-control data-filter="all">functions.php</li>
                    </ul>
                </div>
            </div>
        </div>

        <?php 

        	$wordpress= new WP_Query(array(
        		'post_type' => 'mwordpress',
        		'posts_per_page' => 16,
                'orderBy' => 'publish_date',
                'order' => 'ASC'
        	));
         ?>
        <div class="row">
            <div class="col-md-12">
                <div class="portfolio">
                    <div class="row">
                    	<?php 
// 
                    		while ($wordpress->have_posts()) {
                    			$wordpress->the_post();?>
							<div class="col-md-3 col-sm-6 col-xs-6 mix wow flipInX">
	                            <a data-toggle="modal" data-target="#wordpress-modal<?php echo get_the_ID(); ?>"  href="#" class="portfolio-box">
	                                <div class="portfolio-img" style="border: 1px solid #5893cd; height: 150px;">
                                        <?php 
                                            if (get_the_post_thumbnail()) {
                                                ?>
                                                <?php the_post_thumbnail('full'); ?>
                                                <?php
                                            }else{
                                                ?>
                                                <img src="<?php echo get_theme_file_uri('/media/hello-section/wordpress.jpg'); ?>" alt="" class="img-responsive">
                                                <?php
                                            }

                                         ?>
	                                </div>
	                                <div class="portfolio-name">
	                                    <span><?php the_title(); ?></span>
	                                </div>
	                                <div class="portfolio-date">
	                                    <span></span>
	                                </div>
	                            </a>
	                        </div>
<!-- The text field -->
<!-- <input type="text" value="Hello World" > -->
<textarea class="tests" id="myInput<?php echo get_the_ID(); ?>" ><?php $tss= get_the_content(); remove_filter( $tss, 'wpautop' ); echo $tss; ?>
</textarea>

<?php 
    if (get_field('fontend')) {
        ?>
    <textarea class="tests" id="front<?php echo get_the_ID(); ?>" ><?php $front= get_field('fontend');echo $front; ?>
    </textarea>
        <?php
    }

 ?>
<!-- modal -->
<div class="modal fade" id="wordpress-modal<?php echo get_the_ID(); ?>" tabindex="-1" role="dialog" aria-labelledby="wordpress-modal">
    <div class="modal-dialog" role="document">
        <div class="modal-content" >
            <!-- The button used to copy the text -->
            <div class="modal-body" data-name="patty">
                <?php 
                    if (get_the_content()) {
                        ?>
                <div class="modal-title">
                    <h1 style="font-size: 20px;"><span class="point">Code in functions.php</span></h1>
                </div>
                <div class="modal-description">
                   <?php $text = get_the_content(); ?>
                   <pre style="padding-top: 20px; margin-top: 10px; overflow: hidden;"><?php echo htmlspecialchars($text); ?></pre>
                </div>
                <div class="about-btns" style="margin-top: 10px;">
                    <button class="site-btn"  onclick="myFunction('<?php echo get_the_ID(); ?>')">Copy Code</button>
                    <a href="#" class="site-btn gray-btn" data-dismiss="modal">Close</a>
                </div>
                        <?php
                    }

                 ?>
                <?php 
                    if (get_field('fontend')) {
                        ?>
                    <div class="modal-title" style="margin-top: 20px;">
                        <h1 style="font-size: 20px;"><span class="point">Code in Front End</span></h1>
                    </div>
                    <div class="modal-description">
                       <?php $front = get_field('fontend'); ?>
                       <!-- <pre style="padding-top: 20px; margin-top: 10px; overflow: hidden;"><code></code></pre> -->
                      <pre><?php echo htmlspecialchars($front); ?></pre>
                    </div>
                    <div class="about-btns" style="margin-top: 10px;">
                        <button class="site-btn"  onclick="myFunction2('<?php echo get_the_ID(); ?>')">Copy Code</button>
                        <a href="#" class="site-btn gray-btn" data-dismiss="modal">Close</a>
                    </div>
                        <?php
                    }
                 ?>
            </div>
        </div>
    </div>
</div>
<!-- end modal -->
                    		<?php
                    		}

                    	 ?>
                         <?php wp_reset_postdata(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

</section>

<div class="container">
    <div id="snackbar">It's Copied..</div>
</div>


<?php get_footer(); ?>